import React, { useState } from 'react';
import { 
  User, 
  Briefcase, 
  DollarSign, 
  ShieldCheck, 
  Sparkles, 
  AlertCircle, 
  MapPin, 
  Calendar, 
  CreditCard, 
  Clock, 
  Layers, 
  FileCheck2, 
  Zap, 
  HelpCircle 
} from 'lucide-react';
import { FinancialInput, ValidationError } from '../types/finance.ts';

interface LoanEligibilityFormProps {
  onSubmit: (data: FinancialInput, saveToSheets: boolean) => Promise<void>;
  isLoading: boolean;
}

const SAMPLE_PRESETS: { label: string; desc: string; data: FinancialInput }[] = [
  {
    label: 'Prime Salaried (₹95K/mo)',
    desc: 'Low Risk · High Eligibility (84%)',
    data: {
      fullName: 'Vikram Malhotra',
      age: 31,
      city: 'Mumbai',
      employmentType: 'Salaried',
      employmentDurationYears: 5,
      monthlyIncome: 95000,
      existingMonthlyEmi: 15000,
      existingLoans: 1,
      desiredLoanAmount: 750000,
      loanTenureYears: 5,
      creditScore: 765,
      paymentHistory: 'Clean (100% on-time)',
      creditUtilization: 22,
      numberOfCreditAccounts: 4,
      recentCreditApplications: 1,
      creditHistoryLengthYears: 6,
    },
  },
  {
    label: 'Business Owner (₹1.8L/mo)',
    desc: 'Moderate DTI · ₹15L Loan',
    data: {
      fullName: 'Anita Desai',
      age: 38,
      city: 'Delhi NCR',
      employmentType: 'Business Owner',
      employmentDurationYears: 7,
      monthlyIncome: 180000,
      existingMonthlyEmi: 42000,
      existingLoans: 2,
      desiredLoanAmount: 1500000,
      loanTenureYears: 5,
      creditScore: 738,
      paymentHistory: 'Clean (100% on-time)',
      creditUtilization: 35,
      numberOfCreditAccounts: 6,
      recentCreditApplications: 2,
      creditHistoryLengthYears: 9,
    },
  },
  {
    label: 'Young Freelancer (₹48K/mo)',
    desc: 'Building Credit · Moderate Risk',
    data: {
      fullName: 'Rohan Verma',
      age: 24,
      city: 'Pune',
      employmentType: 'Freelancer',
      employmentDurationYears: 2,
      monthlyIncome: 48000,
      existingMonthlyEmi: 8000,
      existingLoans: 1,
      desiredLoanAmount: 350000,
      loanTenureYears: 4,
      creditScore: 685,
      paymentHistory: 'Occasional late (30-60 days)',
      creditUtilization: 45,
      numberOfCreditAccounts: 3,
      recentCreditApplications: 3,
      creditHistoryLengthYears: 3,
    },
  },
];

export const LoanEligibilityForm: React.FC<LoanEligibilityFormProps> = ({
  onSubmit,
  isLoading,
}) => {
  const [formData, setFormData] = useState<FinancialInput>({
    fullName: 'Rahul Sharma',
    age: 29,
    city: 'Bengaluru',
    employmentType: 'Salaried',
    employmentDurationYears: 4,
    monthlyIncome: 85000,
    existingMonthlyEmi: 12000,
    existingLoans: 1,
    desiredLoanAmount: 750000,
    loanTenureYears: 5,
    creditScore: 742,
    paymentHistory: 'Clean (100% on-time)',
    creditUtilization: 28,
    numberOfCreditAccounts: 4,
    recentCreditApplications: 1,
    creditHistoryLengthYears: 5,
  });

  const [saveToSheets, setSaveToSheets] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Real-time calculation of Debt to Income ratio
  const dti = formData.monthlyIncome > 0
    ? Math.round((formData.existingMonthlyEmi / formData.monthlyIncome) * 100)
    : 0;

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName || formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Full Name must be at least 2 characters.';
    }

    if (!formData.age || formData.age < 18 || formData.age > 70) {
      newErrors.age = 'Age must be between 18 and 70 years.';
    }

    if (!formData.city || formData.city.trim().length < 2) {
      newErrors.city = 'Please enter your current city.';
    }

    if (!formData.monthlyIncome || formData.monthlyIncome <= 0) {
      newErrors.monthlyIncome = 'Monthly income must be greater than ₹0.';
    }

    if (formData.existingMonthlyEmi < 0) {
      newErrors.existingMonthlyEmi = 'Existing EMI cannot be negative.';
    }

    if (!formData.desiredLoanAmount || formData.desiredLoanAmount <= 0) {
      newErrors.desiredLoanAmount = 'Desired loan amount must be greater than ₹0.';
    }

    if (!formData.loanTenureYears || formData.loanTenureYears < 1 || formData.loanTenureYears > 30) {
      newErrors.loanTenureYears = 'Loan tenure must be between 1 and 30 years.';
    }

    if (!formData.creditScore || formData.creditScore < 300 || formData.creditScore > 900) {
      newErrors.creditScore = 'Credit score must be between 300 and 900.';
    }

    if (formData.creditUtilization < 0 || formData.creditUtilization > 100) {
      newErrors.creditUtilization = 'Credit utilization must be between 0% and 100%.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    await onSubmit(formData, saveToSheets);
  };

  const handleApplyPreset = (preset: FinancialInput) => {
    setFormData({ ...preset });
    setErrors({});
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Preset Banner */}
      <div className="mb-8 p-4 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900 to-violet-950/40 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400 flex items-center gap-1.5 font-semibold">
            <Zap className="w-3.5 h-3.5" />
            Instant Evaluation Presets
          </span>
          <p className="text-xs text-slate-300 mt-0.5">
            Demonstration profiles with pre-calibrated BFSI underwriting parameters:
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {SAMPLE_PRESETS.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplyPreset(preset.data)}
              className="px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700/90 border border-white/10 hover:border-cyan-500/40 text-xs font-medium text-slate-200 hover:text-white transition-all text-left"
            >
              <div className="font-semibold">{preset.label}</div>
              <div className="text-[10px] text-slate-400">{preset.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Glass Form */}
      <form onSubmit={handleSubmit} className="glass-panel rounded-3xl border border-white/10 shadow-2xl p-6 sm:p-10 relative">
        
        {/* Form Title & Live DTI Indicator */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-8 border-b border-white/10 gap-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
              Step 1 of 2 · Financial Profile Ingestion
            </span>
            <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
              Enter Financial Information
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Data is validated locally before reaching the central Claude AI decision engine.
            </p>
          </div>

          <div className="px-4 py-2 rounded-xl bg-slate-900/90 border border-white/10 flex items-center gap-3">
            <div className="text-right">
              <div className="text-[10px] font-mono text-slate-400 uppercase">Live DTI Ratio</div>
              <div className={`text-base font-bold font-mono ${dti <= 35 ? 'text-emerald-400' : dti <= 50 ? 'text-yellow-400' : 'text-rose-400'}`}>
                {dti}%
              </div>
            </div>
            <div className={`w-2.5 h-2.5 rounded-full ${dti <= 35 ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50' : dti <= 50 ? 'bg-yellow-400' : 'bg-rose-400'}`} />
          </div>
        </div>

        {/* 4 Form Sections */}
        <div className="space-y-8">
          
          {/* Section 1: Personal Information */}
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-cyan-400 mb-4 uppercase tracking-wider font-mono">
              <User className="w-4 h-4" />
              <span>1. Personal Information</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Full Name <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Rahul Sharma"
                    className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                      errors.fullName ? 'border-rose-500' : 'border-white/10 focus:border-cyan-500'
                    } text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all`}
                  />
                </div>
                {errors.fullName && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.fullName}
                  </p>
                )}
              </div>

              {/* Age */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Age (18–70) <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="18"
                    max="70"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                    className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                      errors.age ? 'border-rose-500' : 'border-white/10 focus:border-cyan-500'
                    } text-sm text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all font-mono`}
                  />
                </div>
                {errors.age && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.age}
                  </p>
                )}
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  City <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Bengaluru, Mumbai, Pune"
                    className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                      errors.city ? 'border-rose-500' : 'border-white/10 focus:border-cyan-500'
                    } text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all`}
                  />
                </div>
                {errors.city && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.city}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Employment Information */}
          <div className="pt-4 border-t border-white/5">
            <div className="flex items-center gap-2 text-sm font-semibold text-blue-400 mb-4 uppercase tracking-wider font-mono">
              <Briefcase className="w-4 h-4" />
              <span>2. Employment Information</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Employment Type */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Employment Type
                </label>
                <select
                  value={formData.employmentType}
                  onChange={(e) => setFormData({ ...formData, employmentType: e.target.value as any })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-blue-500 transition-all"
                >
                  <option value="Salaried">Salaried (Corporate / Govt / MNC)</option>
                  <option value="Self Employed">Self Employed Professional</option>
                  <option value="Business Owner">Business Owner / Enterprise</option>
                  <option value="Freelancer">Freelancer / Gig Economy</option>
                  <option value="Student">Student</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Employment Duration */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Employment Duration (Years)
                </label>
                <input
                  type="number"
                  min="0"
                  max="45"
                  value={formData.employmentDurationYears}
                  onChange={(e) => setFormData({ ...formData, employmentDurationYears: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-blue-500 transition-all font-mono"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Financial Information */}
          <div className="pt-4 border-t border-white/5">
            <div className="flex items-center gap-2 text-sm font-semibold text-violet-400 mb-4 uppercase tracking-wider font-mono">
              <DollarSign className="w-4 h-4" />
              <span>3. Financial Information</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {/* Monthly Income */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Monthly Income (₹) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  step="1000"
                  value={formData.monthlyIncome}
                  onChange={(e) => setFormData({ ...formData, monthlyIncome: parseInt(e.target.value) || 0 })}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                    errors.monthlyIncome ? 'border-rose-500' : 'border-white/10 focus:border-violet-500'
                  } text-sm text-white focus:outline-none focus:ring-1 focus:ring-violet-500/50 font-mono`}
                />
                {errors.monthlyIncome && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.monthlyIncome}
                  </p>
                )}
              </div>

              {/* Existing Monthly EMI */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Existing Monthly EMI (₹)
                </label>
                <input
                  type="number"
                  step="500"
                  value={formData.existingMonthlyEmi}
                  onChange={(e) => setFormData({ ...formData, existingMonthlyEmi: parseInt(e.target.value) || 0 })}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                    errors.existingMonthlyEmi ? 'border-rose-500' : 'border-white/10 focus:border-violet-500'
                  } text-sm text-white focus:outline-none focus:ring-1 focus:ring-violet-500/50 font-mono`}
                />
                {errors.existingMonthlyEmi && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.existingMonthlyEmi}
                  </p>
                )}
              </div>

              {/* Existing Active Loans Count */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Existing Active Loans
                </label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={formData.existingLoans}
                  onChange={(e) => setFormData({ ...formData, existingLoans: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-violet-500 font-mono"
                />
              </div>

              {/* Desired Loan Amount */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Desired Loan Amount (₹) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  step="10000"
                  value={formData.desiredLoanAmount}
                  onChange={(e) => setFormData({ ...formData, desiredLoanAmount: parseInt(e.target.value) || 0 })}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                    errors.desiredLoanAmount ? 'border-rose-500' : 'border-white/10 focus:border-violet-500'
                  } text-sm text-white focus:outline-none focus:ring-1 focus:ring-violet-500/50 font-mono`}
                />
                {errors.desiredLoanAmount && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.desiredLoanAmount}
                  </p>
                )}
              </div>

              {/* Loan Tenure */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Loan Tenure (Years) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={formData.loanTenureYears}
                  onChange={(e) => setFormData({ ...formData, loanTenureYears: parseInt(e.target.value) || 0 })}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                    errors.loanTenureYears ? 'border-rose-500' : 'border-white/10 focus:border-violet-500'
                  } text-sm text-white focus:outline-none focus:ring-1 focus:ring-violet-500/50 font-mono`}
                />
                {errors.loanTenureYears && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.loanTenureYears}
                  </p>
                )}
              </div>

              {/* Credit Score */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Credit Score (300–900) <span className="text-rose-400">*</span></span>
                  <span className={`text-[10px] font-mono font-semibold ${
                    formData.creditScore >= 750 ? 'text-emerald-400' : formData.creditScore >= 670 ? 'text-cyan-400' : 'text-amber-400'
                  }`}>
                    {formData.creditScore >= 750 ? 'Prime' : formData.creditScore >= 670 ? 'Good' : 'Subprime'}
                  </span>
                </label>
                <input
                  type="number"
                  min="300"
                  max="900"
                  value={formData.creditScore}
                  onChange={(e) => setFormData({ ...formData, creditScore: parseInt(e.target.value) || 0 })}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border ${
                    errors.creditScore ? 'border-rose-500' : 'border-white/10 focus:border-violet-500'
                  } text-sm text-white focus:outline-none focus:ring-1 focus:ring-violet-500/50 font-mono`}
                />
                {errors.creditScore && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.creditScore}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Section 4: Credit Information */}
          <div className="pt-4 border-t border-white/5">
            <div className="flex items-center gap-2 text-sm font-semibold text-emerald-400 mb-4 uppercase tracking-wider font-mono">
              <ShieldCheck className="w-4 h-4" />
              <span>4. Credit Profile & Bureau Signals</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Payment History */}
              <div className="sm:col-span-2 lg:col-span-1">
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Payment History Record
                </label>
                <select
                  value={formData.paymentHistory}
                  onChange={(e) => setFormData({ ...formData, paymentHistory: e.target.value as any })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-emerald-500 transition-all"
                >
                  <option value="Clean (100% on-time)">Clean (100% on-time payments)</option>
                  <option value="Occasional late (30-60 days)">Occasional late (30-60 days in past 2 yrs)</option>
                  <option value="Multiple defaults / delinquencies">Multiple defaults / delinquencies</option>
                </select>
              </div>

              {/* Credit Utilization */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Revolving Credit Utilization (%)</span>
                  <span className={`text-[10px] font-mono ${formData.creditUtilization <= 30 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {formData.creditUtilization <= 30 ? 'Recommended <30%' : 'High Utilization'}
                  </span>
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.creditUtilization}
                  onChange={(e) => setFormData({ ...formData, creditUtilization: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              {/* Credit History Length */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Credit History Vintage (Years)
                </label>
                <input
                  type="number"
                  min="0"
                  max="35"
                  value={formData.creditHistoryLengthYears}
                  onChange={(e) => setFormData({ ...formData, creditHistoryLengthYears: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              {/* Number of Credit Accounts */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Number of Credit Accounts (Cards/Loans)
                </label>
                <input
                  type="number"
                  min="1"
                  max="25"
                  value={formData.numberOfCreditAccounts}
                  onChange={(e) => setFormData({ ...formData, numberOfCreditAccounts: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              {/* Recent Inquiries */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Recent Inquiries (Past 6 Months)
                </label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={formData.recentCreditApplications}
                  onChange={(e) => setFormData({ ...formData, recentCreditApplications: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/70 border border-white/10 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>
            </div>
          </div>

        </div>

        {/* Options & Google Sheets Sync Toggle */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <label className="flex items-center gap-3 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={saveToSheets}
              onChange={(e) => setSaveToSheets(e.target.checked)}
              className="w-4 h-4 rounded border-white/20 bg-slate-900 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-0"
            />
            <span className="text-xs text-slate-300">
              Save analysis record to <strong className="text-white">Google Sheets & Activity Log</strong>
            </span>
          </label>

          <div className="text-[11px] text-slate-400">
            Educational BFSI Underwriting Algorithm + Claude AI
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-6">
          <button
            type="submit"
            disabled={isLoading}
            className={`w-full py-4 px-6 rounded-2xl font-bold text-sm tracking-wide text-white transition-all shadow-xl flex items-center justify-center gap-3 ${
              isLoading
                ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-white/10'
                : 'bg-gradient-to-r from-cyan-500 via-blue-600 to-violet-600 hover:shadow-cyan-500/25 hover:scale-[1.01] active:scale-[0.99] border border-cyan-400/30'
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                <span>Claude AI Engine Analyzing Financial Profile...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-cyan-300 animate-pulse" />
                <span>Analyze with FinSight AI (Claude Engine)</span>
              </>
            )}
          </button>
        </div>

      </form>
    </div>
  );
};
