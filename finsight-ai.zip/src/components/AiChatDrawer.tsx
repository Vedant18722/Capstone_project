import React, { useState } from 'react';
import { X, Send, Sparkles, MessageSquare, Bot, User, CheckCircle2 } from 'lucide-react';
import { FinSightAnalysisResult } from '../types/finance.ts';

interface AiChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentAnalysis: FinSightAnalysisResult | null;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const AiChatDrawer: React.FC<AiChatDrawerProps> = ({
  isOpen,
  onClose,
  currentAnalysis,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: currentAnalysis 
        ? `Hello! I'm FinSight AI, your BFSI credit and underwriting advisor. Based on your current profile (Eligibility: ${currentAnalysis.eligibilityPercentage}%, Credit Score: ${currentAnalysis.creditAnalysis.score}), how can I assist you with your loan structure or financial optimization today?`
        : `Hello! I'm FinSight AI. Ask me anything about loan eligibility criteria, credit score optimization, debt-to-income limits, or EMI calculations.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isSending, setIsSending] = useState(false);

  if (!isOpen) return null;

  const quickQuestions = [
    'How can I increase my loan eligibility to 90%?',
    'Should I choose a 3-year or 5-year loan tenure?',
    'How does reducing credit utilization boost my score?',
    'Will adding a co-applicant lower my interest rate?',
  ];

  const handleSend = async (questionText?: string) => {
    const text = (questionText || inputValue).trim();
    if (!text || isSending) return;

    const userMsg: ChatMessage = {
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsSending(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: text,
          context: currentAnalysis || {},
        }),
      });

      const data = await res.json();
      if (data.success && data.answer) {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: data.answer,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: data.error || 'FinSight AI advisor is temporarily taking a breather. Please try again.',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: 'Unable to reach the Claude AI advisor engine. Check connection and retry.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div 
        className="w-full max-w-lg h-full bg-[#0b0f19] border-l border-white/10 flex flex-col shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Ask FinSight AI
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                  Claude
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Context-aware conversational BFSI guidance
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Context Pill */}
        {currentAnalysis && (
          <div className="px-5 py-2.5 bg-white/5 border-b border-white/5 flex items-center justify-between text-xs text-slate-300">
            <span>
              Profile: <strong>{currentAnalysis.input.fullName}</strong>
            </span>
            <span className="font-mono text-cyan-300">
              Eligibility: {currentAnalysis.eligibilityPercentage}% · Score: {currentAnalysis.creditAnalysis.score}
            </span>
          </div>
        )}

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {messages.map((msg, idx) => {
            const isUser = msg.role === 'user';
            return (
              <div key={idx} className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  isUser ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'bg-violet-600/20 text-violet-300 border border-violet-500/30'
                }`}>
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                <div className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  isUser 
                    ? 'bg-cyan-600/20 border border-cyan-500/30 text-white rounded-tr-none' 
                    : 'bg-slate-900 border border-white/10 text-slate-200 rounded-tl-none whitespace-pre-wrap'
                }`}>
                  {msg.content}
                  <div className={`text-[10px] text-slate-500 mt-1.5 ${isUser ? 'text-right' : 'text-left'}`}>
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            );
          })}

          {isSending && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-300">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3 rounded-2xl bg-slate-900 border border-white/10 text-xs text-slate-400">
                FinSight AI is analyzing financial options...
              </div>
            </div>
          )}
        </div>

        {/* Quick Suggestion Pills */}
        <div className="p-3 border-t border-white/5 bg-slate-950/40">
          <div className="text-[10px] text-slate-400 uppercase font-mono mb-2">Suggested queries:</div>
          <div className="flex flex-wrap gap-1.5">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                disabled={isSending}
                className="text-left px-2.5 py-1 rounded-lg bg-slate-900 border border-white/10 hover:border-violet-500/40 text-[11px] text-slate-300 hover:text-white transition-all"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-white/10 bg-slate-900/80">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask about interest rates, DTI, tenure..."
              disabled={isSending}
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 focus:border-cyan-500 text-xs sm:text-sm text-white focus:outline-none placeholder-slate-500"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isSending}
              className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-md shadow-cyan-600/30"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
