import React from 'react';
import { 
  ArrowRight, 
  Sparkles, 
  TrendingUp, 
  ShieldCheck, 
  Calculator, 
  PieChart, 
  CheckCircle2, 
  Cpu, 
  Lock, 
  Layers
} from 'lucide-react';

interface HeroProps {
  onCheckEligibility: () => void;
  onExploreTools: (toolId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onCheckEligibility,
  onExploreTools,
}) => {
  return (
    <div className="relative pt-8 pb-16 overflow-hidden">
      {/* Background glow meshes */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-cyan-600/15 via-blue-600/10 to-violet-600/15 blur-[120px] pointer-events-none rounded-full" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Intelligence Pill */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs text-slate-300 shadow-lg shadow-cyan-950/40">
            <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-medium text-cyan-300">Claude AI Intelligence</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-300">Real-Time BFSI Underwriting</span>
          </div>
        </div>

        {/* Hero Headline & Subheading */}
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15]">
            Smarter Financial Decisions.{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-violet-400 bg-clip-text text-transparent">
              Powered by AI.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
            Analyze your loan eligibility, understand your credit profile, calculate your EMI, and receive personalized financial insights through AI.
          </p>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onCheckEligibility}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-sm shadow-xl shadow-cyan-600/25 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 group"
            >
              <span>Check Loan Eligibility</span>
              <ArrowRight className="w-4 h-4 text-cyan-200 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => onExploreTools('tools-section')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 text-slate-200 hover:text-white font-medium text-sm border border-white/10 hover:border-white/20 transition-all flex items-center justify-center gap-2"
            >
              <span>Explore Financial Tools</span>
            </button>
          </div>

          <div className="mt-6 flex items-center justify-center gap-6 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Institutional BFSI Math
            </span>
            <span className="flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-cyan-400" />
              Zero Banking Credentials Required
            </span>
          </div>
        </div>

        {/* 4 Floating Glass Cards Showcase */}
        <div className="mt-14 max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          
          {/* Card 1: Credit Score */}
          <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group hover:border-cyan-500/40 hover:bg-slate-900/80 transition-all duration-300">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-medium tracking-wide uppercase text-[10px] text-cyan-400">Credit Profile</span>
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono tracking-tight">742</div>
            <div className="mt-1 text-xs text-emerald-400 font-semibold flex items-center gap-1">
              <span>Very Good</span>
              <span className="text-[10px] text-slate-500 font-normal">· Top 18%</span>
            </div>
            <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full w-[78%]" />
            </div>
          </div>

          {/* Card 2: Loan Eligibility */}
          <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group hover:border-blue-500/40 hover:bg-slate-900/80 transition-all duration-300">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-medium tracking-wide uppercase text-[10px] text-blue-400">Eligibility</span>
              <TrendingUp className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono tracking-tight">82%</div>
            <div className="mt-1 text-xs text-cyan-300 font-semibold flex items-center gap-1">
              <span>Estimated Approval</span>
            </div>
            <div className="mt-3 text-[11px] text-slate-400 truncate">
              Eligible: <span className="text-white font-mono font-medium">₹7.5 Lakh</span>
            </div>
          </div>

          {/* Card 3: Monthly EMI */}
          <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group hover:border-violet-500/40 hover:bg-slate-900/80 transition-all duration-300">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-medium tracking-wide uppercase text-[10px] text-violet-400">Monthly EMI</span>
              <Calculator className="w-4 h-4 text-violet-400" />
            </div>
            <div className="text-3xl font-extrabold text-white font-mono tracking-tight">₹21,247</div>
            <div className="mt-1 text-xs text-slate-300 font-medium">
              5 Years Tenure <span className="text-slate-500">@ 9.5%</span>
            </div>
            <div className="mt-3 text-[11px] text-slate-400 truncate">
              Balanced Cashflow Plan
            </div>
          </div>

          {/* Card 4: AI Insight */}
          <div className="glass-panel p-5 rounded-2xl border border-white/10 relative overflow-hidden group hover:border-emerald-500/40 hover:bg-slate-900/80 transition-all duration-300">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-medium tracking-wide uppercase text-[10px] text-emerald-400">AI Assessment</span>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400 font-mono tracking-tight">Low Risk</div>
            <div className="mt-1 text-xs text-slate-300 font-medium">
              DTI Ratio <span className="text-emerald-400 font-mono">31%</span>
            </div>
            <div className="mt-3 text-[11px] text-slate-400 truncate">
              Institutional Underwriting
            </div>
          </div>

        </div>

        {/* Four Major Platform Tools Navigation Cards */}
        <div id="tools-section" className="mt-16 pt-8 border-t border-white/10">
          <div className="text-center mb-8">
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-full border border-cyan-500/20">
              Unified Platform
            </span>
            <h2 className="text-2xl font-bold text-white mt-2">
              Four Core BFSI Decision Tools
            </h2>
            <p className="text-sm text-slate-400 max-w-xl mx-auto mt-1">
              FinSight AI integrates loan underwriting, credit score decomposition, real-time EMI optimization, and AI advice in one cohesive platform.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Tool 1 */}
            <div 
              onClick={() => onExploreTools('checker')}
              className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-cyan-500/40 hover:bg-slate-900/80 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <h3 className="text-base font-semibold text-white group-hover:text-cyan-300 transition-colors">
                  1. Loan Eligibility Checker
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Evaluate borrowing capacity, debt-to-income (DTI) ratio, institutional risk category, and interest brackets.
                </p>
              </div>
              <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-cyan-400 font-medium">
                <span>Start Evaluation</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Tool 2 */}
            <div 
              onClick={() => onExploreTools('credit')}
              className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-blue-500/40 hover:bg-slate-900/80 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 mb-4 group-hover:scale-110 transition-transform">
                  <PieChart className="w-5 h-5" />
                </div>
                <h3 className="text-base font-semibold text-white group-hover:text-blue-300 transition-colors">
                  2. Credit Score Analyzer
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Interactive circular meter, 5-pillar breakdown, strengths, risk drivers, and roadmap to reach 750+ score.
                </p>
              </div>
              <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-blue-400 font-medium">
                <span>Analyze Score</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Tool 3 */}
            <div 
              onClick={() => onExploreTools('emi')}
              className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-violet-500/40 hover:bg-slate-900/80 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400 mb-4 group-hover:scale-110 transition-transform">
                  <Calculator className="w-5 h-5" />
                </div>
                <h3 className="text-base font-semibold text-white group-hover:text-violet-300 transition-colors">
                  3. EMI Calculator
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Interactive sliders with standard formula, principal vs. interest breakdown, and 3/5/7-year scenario comparisons.
                </p>
              </div>
              <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-violet-400 font-medium">
                <span>Calculate EMI</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Tool 4 */}
            <div 
              onClick={() => onExploreTools('checker')}
              className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-emerald-500/40 hover:bg-slate-900/80 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h3 className="text-base font-semibold text-white group-hover:text-emerald-300 transition-colors">
                  4. AI Financial Tips & Insights
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Claude AI analyzes cashflow vulnerabilities, offers tailored financial advice, and answers custom questions.
                </p>
              </div>
              <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-emerald-400 font-medium">
                <span>Explore Insights</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
