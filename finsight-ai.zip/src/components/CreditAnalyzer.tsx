import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  RotateCcw, 
  ArrowRight, 
  Sparkles, 
  PieChart 
} from 'lucide-react';

interface CreditAnalyzerProps {
  onCheckLoanWithScore?: (score: number, utilization: number) => void;
}

export const CreditAnalyzer: React.FC<CreditAnalyzerProps> = ({ onCheckLoanWithScore }) => {
  const [score, setScore] = useState<number>(742);
  const [paymentHistory, setPaymentHistory] = useState<'clean' | 'occasional' | 'defaults'>('clean');
  const [utilization, setUtilization] = useState<number>(28);
  const [historyYears, setHistoryYears] = useState<number>(6);
  const [accountsCount, setAccountsCount] = useState<number>(4);
  const [recentApplications, setRecentApplications] = useState<number>(1);

  // Compute tier and stats
  const analysis = useMemo(() => {
    let category: 'Excellent' | 'Very Good' | 'Good' | 'Fair' | 'Poor';
    let riskLevel: 'Low' | 'Moderate' | 'High';
    let colorClass = 'text-cyan-400';
    let strokeColor = '#22d3ee';

    if (score >= 800) {
      category = 'Excellent';
      riskLevel = 'Low';
      colorClass = 'text-emerald-400';
      strokeColor = '#34d399';
    } else if (score >= 740) {
      category = 'Very Good';
      riskLevel = 'Low';
      colorClass = 'text-cyan-400';
      strokeColor = '#22d3ee';
    } else if (score >= 670) {
      category = 'Good';
      riskLevel = 'Moderate';
      colorClass = 'text-blue-400';
      strokeColor = '#60a5fa';
    } else if (score >= 580) {
      category = 'Fair';
      riskLevel = 'Moderate';
      colorClass = 'text-amber-400';
      strokeColor = '#fbbf24';
    } else {
      category = 'Poor';
      riskLevel = 'High';
      colorClass = 'text-rose-400';
      strokeColor = '#f87171';
    }

    const strengths: string[] = [];
    const concerns: string[] = [];
    const tips: string[] = [];

    // Strengths analysis
    if (paymentHistory === 'clean') {
      strengths.push('Flawless on-time payment track record (weighs 35% of total score)');
    }
    if (utilization <= 30) {
      strengths.push(`Revolving utilization of ${utilization}% remains well below institutional 30% cap`);
    }
    if (historyYears >= 5) {
      strengths.push(`Credit age of ${historyYears} years provides strong historical repayment vintage`);
    }
    if (recentApplications <= 1) {
      strengths.push('Minimal hard credit inquiries during the past 6 months');
    }

    // Concerns
    if (paymentHistory !== 'clean') {
      concerns.push('Delinquency flags present in payment track record heavily penalize risk tier');
    }
    if (utilization > 40) {
      concerns.push(`High credit utilization (${utilization}%) indicates heavy reliance on revolving credit lines`);
    }
    if (recentApplications >= 3) {
      concerns.push(`${recentApplications} recent credit applications generate hard inquiry drops`);
    }
    if (historyYears < 2) {
      concerns.push('Relatively young credit vintage; lenders prefer mature credit footprints');
    }

    // Tips
    tips.push('Automate minimum payments to guarantee zero accidental 30-day delinquencies.');
    if (utilization > 30) {
      tips.push('Make mid-cycle payments on credit cards prior to monthly statement generation date.');
    }
    tips.push('Keep older credit cards active to preserve your average credit account age.');
    if (recentApplications > 1) {
      tips.push('Pause applying for new credit cards or consumer loans for the next 90 days.');
    }

    return {
      category,
      riskLevel,
      colorClass,
      strokeColor,
      strengths,
      concerns,
      tips,
    };
  }, [score, paymentHistory, utilization, historyYears, accountsCount, recentApplications]);

  // Score meter geometry (300 to 900 scale)
  const normalizedPercentage = Math.min(100, Math.max(0, ((score - 300) / (900 - 300)) * 100));
  const radius = 80;
  const circumference = Math.PI * radius; // 180 degree semi-circle
  const strokeDashoffset = circumference - (normalizedPercentage / 100) * circumference;

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-wider text-blue-400 bg-blue-500/10 px-3 py-1 rounded-full border border-blue-500/20">
          Module 2 · Credit Health Intelligence
        </span>
        <h1 className="text-3xl font-extrabold text-white tracking-tight mt-2">
          Credit Score Analyzer
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Deconstruct your credit score into the 5 core bureau pillars, evaluate risk tiers, and identify targeted score improvement steps.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left 5 Cols: Interactive Score Inputs */}
        <div className="lg:col-span-5 glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <PieChart className="w-4 h-4 text-cyan-400" />
            Credit Profile Inputs
          </h3>

          {/* Score Slider & Input */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-medium text-slate-300">Bureau Score (300–900)</label>
              <input
                type="number"
                min="300"
                max="900"
                value={score}
                onChange={(e) => setScore(Math.min(900, Math.max(300, parseInt(e.target.value) || 300)))}
                className="w-20 px-2 py-1 rounded-lg bg-slate-900 border border-white/10 font-mono text-center text-sm font-bold text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
            <input
              type="range"
              min="300"
              max="900"
              value={score}
              onChange={(e) => setScore(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>300 (Poor)</span>
              <span>650</span>
              <span>750</span>
              <span>900 (Excellent)</span>
            </div>
          </div>

          {/* Payment History */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-300">Payment History</label>
            <select
              value={paymentHistory}
              onChange={(e) => setPaymentHistory(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="clean">Clean (100% on-time record)</option>
              <option value="occasional">Occasional Late (30-60 day slip)</option>
              <option value="defaults">Defaults / Severe Delinquencies</option>
            </select>
          </div>

          {/* Credit Utilization */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-medium text-slate-300">Credit Card Utilization</label>
              <span className="font-mono text-cyan-300 font-bold">{utilization}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={utilization}
              onChange={(e) => setUtilization(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-400"
            />
          </div>

          {/* Credit History Length */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-medium text-slate-300">Credit History Length</label>
              <span className="font-mono text-white font-bold">{historyYears} Years</span>
            </div>
            <input
              type="range"
              min="0"
              max="25"
              value={historyYears}
              onChange={(e) => setHistoryYears(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-violet-400"
            />
          </div>

          {/* Active Accounts & Inquiries */}
          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Active Accounts</label>
              <input
                type="number"
                min="1"
                max="20"
                value={accountsCount}
                onChange={(e) => setAccountsCount(parseInt(e.target.value) || 1)}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 font-mono text-sm text-white"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Recent Inquiries (6mo)</label>
              <input
                type="number"
                min="0"
                max="10"
                value={recentApplications}
                onChange={(e) => setRecentApplications(parseInt(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 font-mono text-sm text-white"
              />
            </div>
          </div>

          {onCheckLoanWithScore && (
            <button
              onClick={() => onCheckLoanWithScore(score, utilization)}
              className="w-full py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
            >
              <span>Check Loan Eligibility with this Score</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

        </div>

        {/* Right 7 Cols: Semi-Circular Gauge Meter & 5-Pillar Decomposition */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Circular Score Meter Card */}
          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 text-center relative overflow-hidden">
            <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
              Credit Bureau Standing
            </div>

            {/* Gauge SVG */}
            <div className="relative w-64 h-36 mx-auto flex items-end justify-center overflow-hidden">
              <svg className="w-64 h-64 -rotate-180" viewBox="0 0 200 200">
                <circle
                  cx="100"
                  cy="100"
                  r={radius}
                  stroke="rgba(255, 255, 255, 0.08)"
                  strokeWidth="14"
                  fill="transparent"
                  strokeDasharray={circumference}
                  strokeDashoffset="0"
                />
                <circle
                  cx="100"
                  cy="100"
                  r={radius}
                  stroke={analysis.strokeColor}
                  strokeWidth="14"
                  fill="transparent"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-700 ease-out"
                />
              </svg>

              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-center">
                <div className="text-4xl sm:text-5xl font-extrabold text-white font-mono tracking-tight">
                  {score}
                </div>
                <div className={`text-xs font-extrabold uppercase tracking-wider mt-1 ${analysis.colorClass}`}>
                  {analysis.category}
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-center gap-4 text-xs">
              <span className="text-slate-400">Risk Level:</span>
              <span className={`font-semibold font-mono px-2 py-0.5 rounded ${
                analysis.riskLevel === 'Low' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-yellow-500/20 text-yellow-300'
              }`}>
                {analysis.riskLevel} Risk
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400">Score Range: 300 to 900</span>
            </div>

            {/* 5 Pillar Breakdown Bar */}
            <div className="mt-6 pt-6 border-t border-white/5 text-left">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono mb-3">
                Bureau Scoring Weights Breakdown
              </h4>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5">
                  <div className="text-[10px] text-slate-400">Payment History</div>
                  <div className="font-bold text-white mt-0.5">35% Weight</div>
                  <div className="text-[10px] text-emerald-400 font-mono">
                    {paymentHistory === 'clean' ? 'Optimal (+)' : 'High Penalty (-)'}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5">
                  <div className="text-[10px] text-slate-400">Credit Utilization</div>
                  <div className="font-bold text-white mt-0.5">30% Weight</div>
                  <div className="text-[10px] text-cyan-400 font-mono">
                    {utilization <= 30 ? 'Controlled (+)' : 'Elevated (-)'}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5">
                  <div className="text-[10px] text-slate-400">Credit History Age</div>
                  <div className="font-bold text-white mt-0.5">15% Weight</div>
                  <div className="text-[10px] text-blue-400 font-mono">
                    {historyYears >= 5 ? 'Mature Vintage' : 'Young Vintage'}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5">
                  <div className="text-[10px] text-slate-400">Credit Mix</div>
                  <div className="font-bold text-white mt-0.5">10% Weight</div>
                  <div className="text-[10px] text-violet-400 font-mono">
                    {accountsCount >= 3 ? 'Balanced Mix' : 'Single Type'}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5 col-span-2 sm:col-span-2">
                  <div className="text-[10px] text-slate-400">New Credit Inquiries</div>
                  <div className="font-bold text-white mt-0.5">10% Weight</div>
                  <div className="text-[10px] text-slate-300 font-mono">
                    {recentApplications <= 1 ? 'Safe (<2 inquiries)' : 'Velocity warning'}
                  </div>
                </div>
              </div>
            </div>

            {/* Strengths & Concerns */}
            <div className="mt-6 pt-6 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Key Strengths
                </span>
                <ul className="mt-2 space-y-1.5 text-xs text-slate-300">
                  {analysis.strengths.map((str, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-emerald-400 font-bold">✓</span>
                      <span>{str}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Potential Concerns
                </span>
                <ul className="mt-2 space-y-1.5 text-xs text-slate-300">
                  {analysis.concerns.length > 0 ? (
                    analysis.concerns.map((con, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-amber-400 font-bold">⚠</span>
                        <span>{con}</span>
                      </li>
                    ))
                  ) : (
                    <li className="text-slate-400 italic">No significant risk drivers detected.</li>
                  )}
                </ul>
              </div>
            </div>

            {/* Actionable Improvement Roadmap */}
            <div className="mt-6 pt-6 border-t border-white/5 text-left">
              <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Actionable Score Improvement Roadmap
              </span>
              <div className="mt-2 space-y-2">
                {analysis.tips.map((tip, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 text-xs text-slate-300 flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{tip}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Mandatory Bureau Disclaimer */}
            <p className="mt-6 text-[11px] text-slate-500 italic text-left flex items-start gap-1.5">
              <Info className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <span>
                <strong>Educational Notice:</strong> FinSight AI credit analysis is an educational estimation tool based on BFSI heuristic models and does NOT represent an official credit bureau score (e.g. CIBIL, Experian, Equifax, or CRIF).
              </span>
            </p>

          </div>

        </div>

      </div>
    </div>
  );
};
