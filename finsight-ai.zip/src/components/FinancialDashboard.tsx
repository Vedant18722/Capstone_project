import React, { useState } from 'react';
import { 
  TrendingUp, 
  ShieldCheck, 
  Calculator, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  FileDown, 
  Save, 
  MessageSquare, 
  RotateCcw, 
  Info, 
  Percent, 
  DollarSign, 
  Clock, 
  Layers, 
  Check, 
  ExternalLink 
} from 'lucide-react';
import { FinSightAnalysisResult } from '../types/finance.ts';

interface FinancialDashboardProps {
  analysis: FinSightAnalysisResult;
  onEditInputs: () => void;
  onOpenChat: () => void;
  onSaveToSheets: (record: FinSightAnalysisResult) => Promise<{ success: boolean; message: string }>;
}

export const FinancialDashboard: React.FC<FinancialDashboardProps> = ({
  analysis,
  onEditInputs,
  onOpenChat,
  onSaveToSheets,
}) => {
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  const handleManualSave = async () => {
    setIsSaving(true);
    setSaveSuccessMsg(null);
    try {
      const res = await onSaveToSheets(analysis);
      setSaveSuccessMsg(res.message);
    } catch (err: any) {
      setSaveSuccessMsg('Saved locally in activity history.');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePrintOrDownload = () => {
    window.print();
  };

  // Color mappings
  const riskColor = 
    analysis.riskLevel === 'Low' ? 'text-emerald-400' :
    analysis.riskLevel === 'Moderate' ? 'text-yellow-400' : 'text-rose-400';
  
  const riskBg = 
    analysis.riskLevel === 'Low' ? 'bg-emerald-500/10 border-emerald-500/30' :
    analysis.riskLevel === 'Moderate' ? 'bg-yellow-500/10 border-yellow-500/30' : 'bg-rose-500/10 border-rose-500/30';

  // Circular progress calculations for SVG
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (analysis.eligibilityPercentage / 100) * circumference;

  return (
    <div className="max-w-7xl mx-auto space-y-8 print:p-0">
      
      {/* Top Banner / Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl glass-panel border border-white/10 print:hidden">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
              Analysis Ref: {analysis.id}
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">
              {new Date(analysis.timestamp).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-0.5">
            Financial Intelligence Snapshot: {analysis.input.fullName}
          </h1>
          <p className="text-xs text-slate-400">
            Synthesized via <span className="text-cyan-300 font-semibold">{analysis.aiEngineUsed}</span> with BFSI actuarial underwriting rules.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onEditInputs}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 hover:border-white/20 text-xs font-medium text-slate-300 hover:text-white transition-all flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
            <span>Modify Inputs</span>
          </button>

          <button
            onClick={handleManualSave}
            disabled={isSaving}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-emerald-500/30 hover:border-emerald-500/50 text-xs font-medium text-emerald-300 hover:text-white transition-all flex items-center gap-1.5"
          >
            {isSaving ? (
              <div className="w-3.5 h-3.5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>Save to Google Sheets</span>
          </button>

          <button
            onClick={onOpenChat}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-xs font-semibold text-white shadow-lg shadow-violet-900/30 hover:shadow-violet-800/40 transition-all flex items-center gap-1.5"
          >
            <MessageSquare className="w-3.5 h-3.5 text-violet-200" />
            <span>Ask FinSight AI</span>
          </button>

          <button
            onClick={handlePrintOrDownload}
            className="px-3 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-medium text-slate-300 hover:text-white transition-all"
            title="Print or Save Statement as PDF"
          >
            <FileDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            {saveSuccessMsg}
          </span>
          <button onClick={() => setSaveSuccessMsg(null)} className="text-emerald-400 hover:text-white text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* 4 PRIMARY METRIC CARDS (As specifically instructed in Section 14) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Card 1: Loan Eligibility */}
        <div className="glass-panel p-6 rounded-2xl border border-cyan-500/30 relative overflow-hidden group hover:border-cyan-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400">
              Loan Eligibility
            </span>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="mt-4 flex items-center justify-between">
            <div>
              <div className="text-4xl font-extrabold text-white font-mono tracking-tight">
                {analysis.eligibilityPercentage}%
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Estimated Limit: <strong className="text-cyan-300 font-mono">₹{(analysis.estimatedLoanAmount / 100000).toFixed(1)} Lakh</strong>
              </p>
            </div>

            {/* Circular Progress Meter */}
            <div className="relative w-16 h-16 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r={radius}
                  className="stroke-slate-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="50"
                  cy="50"
                  r={radius}
                  className="stroke-cyan-400 transition-all duration-1000 ease-out"
                  strokeWidth="8"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="transparent"
                />
              </svg>
              <span className="absolute text-[11px] font-bold font-mono text-cyan-300">
                {analysis.eligibilityPercentage}%
              </span>
            </div>
          </div>
          
          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Approval Probability</span>
            <span className="font-semibold text-emerald-400">High Confidence</span>
          </div>
        </div>

        {/* Card 2: Credit Score */}
        <div className="glass-panel p-6 rounded-2xl border border-blue-500/30 relative overflow-hidden group hover:border-blue-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono uppercase tracking-wider text-blue-400">
              Credit Score
            </span>
            <ShieldCheck className="w-4 h-4 text-blue-400" />
          </div>

          <div className="mt-4 flex items-baseline gap-3">
            <div className="text-4xl font-extrabold text-white font-mono tracking-tight">
              {analysis.creditAnalysis.score}
            </div>
            <div className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20">
              {analysis.creditAssessment}
            </div>
          </div>

          <p className="text-xs text-slate-400 mt-2">
            Range: 300 – 900 · Bureau Tier 1
          </p>

          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Payment Track</span>
            <span className="font-semibold text-cyan-300">{analysis.input.paymentHistory.split(' ')[0]}</span>
          </div>
        </div>

        {/* Card 3: Monthly EMI */}
        <div className="glass-panel p-6 rounded-2xl border border-violet-500/30 relative overflow-hidden group hover:border-violet-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono uppercase tracking-wider text-violet-400">
              Monthly EMI
            </span>
            <Calculator className="w-4 h-4 text-violet-400" />
          </div>

          <div className="mt-4 flex items-baseline gap-2">
            <div className="text-3xl font-extrabold text-white font-mono tracking-tight">
              ₹{analysis.monthlyEmiEstimated.toLocaleString('en-IN')}
            </div>
            <span className="text-xs text-slate-400">/ mo</span>
          </div>

          <p className="text-xs text-slate-400 mt-2">
            Tenure: {analysis.input.loanTenureYears} Years @ {analysis.estimatedInterestRange.split('–')[0].trim()}
          </p>

          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-400 flex items-center justify-between">
            <span>DTI Impact</span>
            <span className="font-semibold text-violet-300 font-mono">+{Math.round((analysis.monthlyEmiEstimated / analysis.input.monthlyIncome) * 100)}%</span>
          </div>
        </div>

        {/* Card 4: Financial Risk */}
        <div className="glass-panel p-6 rounded-2xl border border-emerald-500/30 relative overflow-hidden group hover:border-emerald-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-400">
              Financial Risk
            </span>
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>

          <div className="mt-4 flex items-center gap-3">
            <div className={`text-3xl font-extrabold font-mono tracking-tight ${riskColor}`}>
              {analysis.riskLevel} Risk
            </div>
          </div>

          <p className="text-xs text-slate-400 mt-2">
            DTI Ratio: <span className="text-white font-semibold font-mono">{analysis.debtToIncomeRatio}%</span> (FOIR Limit &lt;50%)
          </p>

          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Repayment Capacity</span>
            <span className="font-semibold text-emerald-400">{analysis.repaymentCapacity}</span>
          </div>
        </div>

      </div>

      {/* SECTION 9 & 10: ELIGIBILITY & RISK ASSESSMENT + AI FINANCIAL INSIGHTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Eligibility Details & AI Financial Insights */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Eligibility & Risk Breakdown Panel */}
          <div className="glass-panel p-6 rounded-2xl border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  Eligibility Analysis & Institutional Underwriting
                </h3>
                <p className="text-xs text-slate-400">
                  Calculated against standard banking FOIR (Fixed Obligation to Income Ratio) limits
                </p>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${riskBg} ${riskColor}`}>
                {analysis.riskLevel} Risk Tier
              </span>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-y border-white/5">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase">Estimated Limit</span>
                <div className="text-lg font-bold text-white font-mono mt-0.5">
                  ₹{analysis.estimatedLoanAmount.toLocaleString('en-IN')}
                </div>
                <span className="text-[10px] text-emerald-400">Institutional Max</span>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase">DTI Ratio</span>
                <div className="text-lg font-bold text-white font-mono mt-0.5">
                  {analysis.debtToIncomeRatio}%
                </div>
                <span className="text-[10px] text-slate-400">Current Obligation</span>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase">Est. Interest Range</span>
                <div className="text-lg font-bold text-white font-mono mt-0.5">
                  {analysis.estimatedInterestRange}
                </div>
                <span className="text-[10px] text-cyan-300">Prime Lending Rate</span>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase">Repayment Capacity</span>
                <div className="text-lg font-bold text-emerald-400 mt-0.5">
                  {analysis.repaymentCapacity}
                </div>
                <span className="text-[10px] text-slate-400">Net Disposable</span>
              </div>
            </div>

            {/* Detailed AI Underwriter Synthesis */}
            <div className="mt-5 p-4 rounded-xl bg-slate-900/80 border border-white/5">
              <div className="flex items-center gap-2 text-xs font-mono text-cyan-300 uppercase tracking-wider mb-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                Underwriter Decision Summary
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {analysis.loanInsights}
              </p>
            </div>

            {/* Educational Disclaimer */}
            <p className="mt-4 text-[11px] text-slate-500 italic flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              This is an estimated educational assessment and does not represent actual bank approval.
            </p>
          </div>

          {/* AI Financial Insights & Actionable Tips */}
          <div className="glass-panel p-6 rounded-2xl border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-violet-400" />
                  AI Financial Tips & Behavioral Insights
                </h3>
                <p className="text-xs text-slate-400">
                  Customized recommendations synthesized from your cashflow and credit profile
                </p>
              </div>

              <button
                onClick={onOpenChat}
                className="px-3 py-1.5 rounded-lg bg-violet-500/20 hover:bg-violet-500/30 text-violet-300 border border-violet-500/30 text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <span>Ask FinSight AI</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* AI Recommendation Quote */}
            <div className="p-4 rounded-xl bg-violet-950/20 border border-violet-500/20 text-xs sm:text-sm text-slate-200 leading-relaxed mb-4">
              "{analysis.emiRecommendation}"
            </div>

            {/* Bulleted Personalized Tips */}
            <div className="space-y-2.5">
              <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                Personalized Action Plan
              </span>
              {analysis.financialTips.map((tip, idx) => (
                <div key={idx} className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-900/60 border border-white/5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{tip}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right 1 Col: Financial Signals & Credit Snapshot */}
        <div className="space-y-6">
          
          {/* Financial Signals */}
          <div className="glass-panel p-6 rounded-2xl border border-white/10">
            <h3 className="text-base font-bold text-white mb-1">
              Financial Signals & Health Audit
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Key indicators influencing lender risk modeling
            </p>

            <div className="space-y-3">
              {analysis.financialSignals.map((signal, idx) => {
                const isPos = signal.type === 'positive';
                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border text-xs ${
                      isPos 
                        ? 'bg-emerald-950/20 border-emerald-500/25 text-emerald-200' 
                        : 'bg-amber-950/20 border-amber-500/25 text-amber-200'
                    }`}
                  >
                    <div className="font-semibold flex items-center gap-1.5 mb-1">
                      {isPos ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      )}
                      <span>{signal.title}</span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      {signal.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Credit Standing Snapshot */}
          <div className="glass-panel p-6 rounded-2xl border border-white/10">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white">
                Credit Profile Scorecard
              </h3>
              <span className="text-xs font-mono text-cyan-400 font-bold">
                {analysis.creditAnalysis.score} / 900
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1.5 border-b border-white/5">
                <span className="text-slate-400">Payment History</span>
                <span className="font-medium text-white">{analysis.creditAnalysis.paymentHistoryImpact.split('(')[0]}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5">
                <span className="text-slate-400">Credit Utilization</span>
                <span className="font-mono text-white">{analysis.input.creditUtilization}%</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5">
                <span className="text-slate-400">Active Lines</span>
                <span className="font-mono text-white">{analysis.input.numberOfCreditAccounts} Accounts</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-400">Credit Vintage</span>
                <span className="font-mono text-white">{analysis.input.creditHistoryLengthYears} Years</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* SECTION 11: EMI SUGGESTIONS & LOAN INSIGHTS SCENARIO COMPARISON */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-6 border-b border-white/10 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400">
                Module 3 · Loan Structuring
              </span>
              <span className="text-slate-500">·</span>
              <span className="text-xs text-slate-400">Principal: ₹{analysis.input.desiredLoanAmount.toLocaleString('en-IN')}</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight mt-0.5">
              EMI Suggestions & Alternative Scenario Comparison
            </h2>
            <p className="text-xs text-slate-400">
              Visually compare 3-Year, 5-Year, and 7-Year amortization structures to optimize total interest versus monthly liquidity.
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Benchmark APR</span>
            <div className="text-base font-bold text-cyan-400 font-mono">
              {analysis.loanPlans[0]?.interestRate || 10.5}% p.a.
            </div>
          </div>
        </div>

        {/* 3 Scenario Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {analysis.loanPlans.map((plan, idx) => (
            <div
              key={idx}
              className={`p-5 rounded-2xl border transition-all relative flex flex-col justify-between ${
                plan.isRecommended
                  ? 'bg-gradient-to-b from-cyan-950/40 via-slate-900 to-slate-900 border-cyan-500/40 shadow-xl shadow-cyan-950/30'
                  : 'bg-slate-900/60 border-white/10 hover:border-white/20'
              }`}
            >
              {plan.isRecommended && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-cyan-500 text-black font-extrabold text-[10px] uppercase tracking-wider shadow-md">
                  Recommended Balance
                </div>
              )}

              <div>
                <div className="flex items-center justify-between">
                  <h4 className="text-base font-bold text-white">
                    {plan.scenarioName}
                  </h4>
                  <span className="text-xs font-mono text-slate-400">
                    {plan.tenureYears * 12} Months
                  </span>
                </div>

                <div className="mt-4">
                  <span className="text-[10px] font-mono text-slate-400 uppercase">Monthly EMI</span>
                  <div className="text-2xl font-extrabold text-white font-mono mt-0.5">
                    ₹{plan.emi.toLocaleString('en-IN')}
                  </div>
                </div>

                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  {plan.summary}
                </p>

                <div className="mt-4 pt-3 border-t border-white/5 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Interest</span>
                    <span className="font-mono text-rose-300 font-medium">₹{plan.totalInterest.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Outlay</span>
                    <span className="font-mono text-white font-semibold">₹{plan.totalPayment.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-white/5">
                <div className="text-[10px] text-slate-400">
                  {plan.tenureYears === 3 && 'Saves up to ₹1.5L in interest charges'}
                  {plan.tenureYears === 5 && 'Optimal debt servicing ratio for salaried profiles'}
                  {plan.tenureYears === 7 && 'Maximizes immediate take-home cashflow'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
