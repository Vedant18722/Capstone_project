import React from 'react';
import { ShieldCheck, AlertCircle, Lock } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
}) => {
  return (
    <footer className="border-t border-white/10 bg-[#05070a] mt-20 pt-14 pb-10 text-xs text-slate-400 print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center text-white">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                FinSight <span className="text-cyan-400">AI</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-md">
              Smarter Financial Decisions. Powered by AI. An institutional BFSI decision-support platform integrating loan eligibility underwriting, credit bureau pillar decomposition, real-time EMI optimization, and Anthropic Claude AI intelligence.
            </p>
          </div>

          {/* Core Tools */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
              Platform Tools
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('checker')}
                  className="hover:text-cyan-300 transition-colors"
                >
                  Loan Eligibility Checker
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('credit')}
                  className="hover:text-cyan-300 transition-colors"
                >
                  Credit Score Analyzer
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('emi')}
                  className="hover:text-cyan-300 transition-colors"
                >
                  EMI Calculator & Scenarios
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('history')}
                  className="hover:text-cyan-300 transition-colors"
                >
                  Activity Audit History
                </button>
              </li>
            </ul>
          </div>

          {/* Underwriting Standards */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">
              BFSI Standards
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>Fixed Obligation to Income (FOIR)</li>
              <li>Debt-to-Income (DTI) Guardrails</li>
              <li>Compound Amortization Math</li>
              <li>5-Pillar Credit Decomposition</li>
              <li>Google Sheets Webhook Sync</li>
            </ul>
          </div>

        </div>

        {/* Security & Disclaimer Boxes (Section 26) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-white/5 text-[11px] text-slate-400">
          
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 space-y-1">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Educational Financial Disclaimer</span>
            </div>
            <p className="leading-relaxed">
              FinSight AI provides educational financial estimates and AI-generated guidance. Results do not represent actual bank approval and should not be considered professional financial advice. Actual loan sanction is subject to lender credit policies, physical verification, and bureau audits.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 space-y-1">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>Consumer Privacy & Data Protection</span>
            </div>
            <p className="leading-relaxed">
              FinSight AI will never request or store banking passwords, one-time passwords (OTPs), ATM PINs, card CVVs, or login credentials. Calculations are processed in-memory and via secure server-side API proxy.
            </p>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} FinSight AI Platform. Smarter Financial Decisions. Powered by AI.
          </div>
          <div className="flex items-center gap-2">
            <span>Built with Claude AI Architecture & React 19</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
