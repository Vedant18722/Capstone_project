import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Menu, 
  X, 
  Sparkles, 
  Calculator, 
  FileText, 
  History, 
  Gauge,
  Download
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'checker', label: 'Loan Eligibility' },
    { id: 'credit', label: 'Credit Analyzer' },
    { id: 'emi', label: 'EMI Calculator' },
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'history', label: 'Activity History' },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#07090e]/85 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        
        {/* Brand */}
        <div 
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 p-[1px] shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-500/40 transition-shadow">
            <div className="w-full h-full bg-[#0b0f19] rounded-[11px] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                FinSight <span className="text-cyan-400">AI</span>
              </span>
              <span className="text-[10px] uppercase font-mono tracking-wider px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                Claude Powered
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
              Smarter Financial Decisions. Powered by AI.
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3.5 py-2 text-sm font-medium rounded-lg transition-all ${
                  isActive
                    ? 'text-cyan-300 bg-cyan-500/10 shadow-sm border border-cyan-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Desktop Right Action */}
        <div className="hidden sm:flex items-center gap-2.5">
          <a
            href="/api/download-zip"
            download="finsight-ai.zip"
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 rounded-lg border border-white/10 transition-colors"
            title="Download full project ZIP archive"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Download ZIP</span>
          </a>

          <button
            onClick={() => handleNavClick('checker')}
            className="px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 rounded-lg shadow-md shadow-cyan-600/20 transition-all"
          >
            Check Eligibility
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="flex lg:hidden items-center gap-2">
          <a
            href="/api/download-zip"
            download="finsight-ai.zip"
            className="p-2 text-slate-300 hover:text-white rounded-lg bg-white/5 border border-white/10"
            title="Download Project ZIP"
          >
            <Download className="w-4 h-4 text-cyan-400" />
          </a>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-300 hover:text-white rounded-lg bg-white/5 border border-white/10"
            aria-label="Toggle navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile dropdown menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-white/10 bg-[#0b0f19] px-4 pt-3 pb-5 space-y-2">
          <p className="text-xs text-slate-400 px-3 py-1">FinSight AI Navigation</p>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === item.id
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/25'
                  : 'text-slate-300 hover:bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-white/10 space-y-2">
            <a
              href="/api/download-zip"
              download="finsight-ai.zip"
              className="w-full flex items-center justify-center gap-1.5 py-2.5 text-center text-xs font-medium text-slate-200 bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download Project ZIP</span>
            </a>
            <button
              onClick={() => handleNavClick('checker')}
              className="w-full py-2.5 text-center text-xs font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg shadow-md"
            >
              Check Loan Eligibility
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
