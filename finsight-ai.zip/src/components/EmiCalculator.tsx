import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  DollarSign, 
  Percent, 
  Calendar, 
  TrendingUp, 
  PieChart, 
  Sparkles, 
  RotateCcw, 
  ArrowRight 
} from 'lucide-react';
import { calculateEmi } from '../server/financeEngine.ts';

interface EmiCalculatorProps {
  onApplyToChecker?: (amount: number, tenure: number) => void;
}

export const EmiCalculator: React.FC<EmiCalculatorProps> = ({ onApplyToChecker }) => {
  const [principal, setPrincipal] = useState<number>(750000);
  const [interestRate, setInterestRate] = useState<number>(10.5);
  const [tenureYears, setTenureYears] = useState<number>(5);

  // Real-time calculation using the exact standard formula
  const result = useMemo(() => {
    return calculateEmi(principal, interestRate, tenureYears);
  }, [principal, interestRate, tenureYears]);

  const principalPercent = result.totalPayment > 0 
    ? Math.round((principal / result.totalPayment) * 100) 
    : 100;
  const interestPercent = 100 - principalPercent;

  const presets = [
    { name: 'Personal Loan', p: 500000, r: 11.5, t: 5 },
    { name: 'Home Loan', p: 3500000, r: 8.5, t: 20 },
    { name: 'Car Loan', p: 800000, r: 9.0, t: 5 },
    { name: 'Education Loan', p: 1500000, r: 9.5, t: 7 },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono uppercase tracking-wider text-violet-400 bg-violet-500/10 px-3 py-1 rounded-full border border-violet-500/20">
          Module 3 · Precision Mathematical Engine
        </span>
        <h1 className="text-3xl font-extrabold text-white tracking-tight mt-2">
          Interactive EMI Calculator
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Compute real-time monthly installments, total interest accrual, and principal breakdowns using standard banking amortization formulas.
        </p>
      </div>

      {/* Preset Buttons */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        <span className="text-xs text-slate-400 mr-2">Quick Benchmarks:</span>
        {presets.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => {
              setPrincipal(preset.p);
              setInterestRate(preset.r);
              setTenureYears(preset.t);
            }}
            className="px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 hover:border-violet-500/40 text-xs font-medium text-slate-300 hover:text-white transition-all"
          >
            {preset.name} (₹{(preset.p / 100000).toFixed(1)}L @ {preset.r}%)
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Sliders & Number Inputs */}
        <div className="lg:col-span-7 glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 space-y-8">
          
          {/* 1. Loan Amount */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-cyan-400" />
                <span>Loan Amount</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">₹</span>
                <input
                  type="number"
                  step="10000"
                  min="50000"
                  max="10000000"
                  value={principal}
                  onChange={(e) => setPrincipal(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-40 pl-7 pr-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 focus:border-cyan-500 text-sm font-mono text-white text-right focus:outline-none"
                />
              </div>
            </div>

            <input
              type="range"
              min="50000"
              max="10000000"
              step="25000"
              value={principal}
              onChange={(e) => setPrincipal(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>₹50K</span>
              <span>₹25 Lakh</span>
              <span>₹50 Lakh</span>
              <span>₹1 Crore</span>
            </div>
          </div>

          {/* 2. Interest Rate */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Percent className="w-4 h-4 text-violet-400" />
                <span>Interest Rate (% per annum)</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  min="5"
                  max="25"
                  value={interestRate}
                  onChange={(e) => setInterestRate(parseFloat(e.target.value) || 0)}
                  className="w-28 px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 focus:border-violet-500 text-sm font-mono text-white text-right focus:outline-none"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">%</span>
              </div>
            </div>

            <input
              type="range"
              min="5"
              max="25"
              step="0.1"
              value={interestRate}
              onChange={(e) => setInterestRate(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-violet-400"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>5%</span>
              <span>10%</span>
              <span>15%</span>
              <span>25%</span>
            </div>
          </div>

          {/* 3. Loan Tenure */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                <span>Loan Tenure (Years)</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={tenureYears}
                  onChange={(e) => setTenureYears(parseInt(e.target.value) || 1)}
                  className="w-24 px-3 py-1.5 rounded-xl bg-slate-900 border border-white/10 focus:border-blue-500 text-sm font-mono text-white text-right focus:outline-none"
                />
                <span className="text-xs text-slate-400 font-mono">({tenureYears * 12} mo)</span>
              </div>
            </div>

            <input
              type="range"
              min="1"
              max="30"
              step="1"
              value={tenureYears}
              onChange={(e) => setTenureYears(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-400"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>1 Year</span>
              <span>5 Years</span>
              <span>15 Years</span>
              <span>30 Years</span>
            </div>
          </div>

          {/* Standard Formula Reference */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-white/5 text-xs text-slate-400 space-y-1">
            <div className="font-mono text-cyan-300 font-medium">
              Standard Formula: EMI = P × R × (1+R)ᴺ / ((1+R)ᴺ - 1)
            </div>
            <div>
              Where P = Principal (₹{principal.toLocaleString('en-IN')}), R = Monthly Rate ({(interestRate / 12 / 100).toFixed(6)}), N = {tenureYears * 12} Months.
            </div>
          </div>

        </div>

        {/* Right Column: Results & Visual Ratio Gauge */}
        <div className="lg:col-span-5 space-y-6">
          
          <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-violet-500/30 shadow-2xl relative overflow-hidden flex flex-col justify-between">
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-violet-400">
                Calculated Obligation
              </span>

              {/* Monthly EMI Large */}
              <div className="mt-3">
                <span className="text-xs text-slate-400">Monthly Loan Installment</span>
                <div className="text-4xl sm:text-5xl font-extrabold text-white font-mono tracking-tight mt-1">
                  ₹{result.emi.toLocaleString('en-IN')}
                </div>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  Payable for {result.tenureMonths} consecutive months
                </div>
              </div>

              {/* Breakdown Details */}
              <div className="mt-8 space-y-3.5 pt-6 border-t border-white/10">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 flex items-center gap-2">
                    <span className="w-3 h-3 rounded bg-cyan-400" />
                    Principal Amount
                  </span>
                  <span className="font-mono font-bold text-white">
                    ₹{principal.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 flex items-center gap-2">
                    <span className="w-3 h-3 rounded bg-violet-400" />
                    Total Interest Charge
                  </span>
                  <span className="font-mono font-bold text-violet-300">
                    ₹{result.totalInterest.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="flex items-center justify-between text-sm pt-2 border-t border-white/5">
                  <span className="text-slate-300 font-semibold">Total Amount Payable</span>
                  <span className="font-mono font-extrabold text-white text-base">
                    ₹{result.totalPayment.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Visual Proportion Bar */}
              <div className="mt-6">
                <div className="flex justify-between text-xs text-slate-400 mb-2">
                  <span>Principal: {principalPercent}%</span>
                  <span>Interest: {interestPercent}%</span>
                </div>
                <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden flex">
                  <div 
                    style={{ width: `${principalPercent}%` }} 
                    className="bg-cyan-400 transition-all duration-300" 
                    title={`Principal: ${principalPercent}%`}
                  />
                  <div 
                    style={{ width: `${interestPercent}%` }} 
                    className="bg-violet-500 transition-all duration-300" 
                    title={`Interest: ${interestPercent}%`}
                  />
                </div>
              </div>
            </div>

            {/* Action to transfer to eligibility checker */}
            {onApplyToChecker && (
              <div className="mt-8 pt-6 border-t border-white/10">
                <button
                  onClick={() => onApplyToChecker(principal, tenureYears)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/20"
                >
                  <span>Evaluate My Eligibility For This Loan</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
