import React, { useState, useEffect } from 'react';
import { 
  History, 
  TrendingUp, 
  ShieldCheck, 
  Calculator, 
  Sparkles, 
  ExternalLink, 
  Download, 
  CheckCircle2, 
  RotateCcw, 
  ArrowRight, 
  Search, 
  Database 
} from 'lucide-react';
import { FinSightAnalysisResult } from '../types/finance.ts';

interface HistoryViewProps {
  onSelectRecord: (record: FinSightAnalysisResult) => void;
  onStartNew: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ onSelectRecord, onStartNew }) => {
  const [records, setRecords] = useState<FinSightAnalysisResult[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchHistory = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/history');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setRecords(data.data);
      }
    } catch (err) {
      console.warn('Failed to load history:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const filtered = records.filter((r) => {
    const term = searchTerm.toLowerCase();
    return (
      r.input.fullName.toLowerCase().includes(term) ||
      r.input.city.toLowerCase().includes(term) ||
      r.riskLevel.toLowerCase().includes(term)
    );
  });

  const exportCSV = () => {
    if (records.length === 0) return;
    const headers = [
      'Record ID',
      'Timestamp',
      'Full Name',
      'Age',
      'City',
      'Employment',
      'Monthly Income (INR)',
      'Existing EMI (INR)',
      'Desired Loan (INR)',
      'Tenure (Years)',
      'Credit Score',
      'Eligibility (%)',
      'Risk Level',
      'Estimated Limit (INR)',
      'Monthly EMI (INR)',
      'DTI (%)',
      'AI Engine',
      'Google Sheets Synced',
    ];

    const rows = records.map((r) => [
      r.id,
      r.timestamp,
      `"${r.input.fullName}"`,
      r.input.age,
      `"${r.input.city}"`,
      r.input.employmentType,
      r.input.monthlyIncome,
      r.input.existingMonthlyEmi,
      r.input.desiredLoanAmount,
      r.input.loanTenureYears,
      r.creditAnalysis.score,
      r.eligibilityPercentage,
      r.riskLevel,
      r.estimatedLoanAmount,
      r.monthlyEmiEstimated,
      r.debtToIncomeRatio,
      `"${r.aiEngineUsed}"`,
      r.sheetSynced ? 'YES' : 'NO',
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `FinSight_AI_History_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
            Persistent Audit & Activity Log
          </span>
          <h1 className="text-3xl font-extrabold text-white tracking-tight mt-2">
            Recent Financial Activity
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Historical loan assessments, credit health profiles, and Google Sheets audit sync records.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={exportCSV}
            disabled={records.length === 0}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-white/10 hover:border-cyan-500/40 text-xs font-semibold text-slate-300 hover:text-white transition-all flex items-center gap-1.5 disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onStartNew}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-xs font-semibold text-white shadow-lg shadow-cyan-600/20 hover:scale-[1.02] transition-all flex items-center gap-1.5"
          >
            <span>New Assessment</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search activity by applicant name, city, or risk tier..."
          className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-900/80 border border-white/10 focus:border-cyan-500 text-sm text-white focus:outline-none placeholder-slate-500"
        />
      </div>

      {/* Record Cards */}
      {isLoading ? (
        <div className="text-center py-16">
          <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs text-slate-400">Loading saved assessments...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass-panel p-12 text-center rounded-3xl border border-white/10">
          <History className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">No Financial Activities Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            {searchTerm ? 'No results matched your search term.' : 'Run your first loan eligibility analysis to populate persistent activity.'}
          </p>
          <button
            onClick={onStartNew}
            className="mt-5 px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-colors"
          >
            Run Loan Eligibility Check
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((record) => {
            const riskColor = 
              record.riskLevel === 'Low' ? 'text-emerald-400' :
              record.riskLevel === 'Moderate' ? 'text-yellow-400' : 'text-rose-400';

            return (
              <div
                key={record.id}
                className="glass-panel p-5 rounded-2xl border border-white/10 hover:border-cyan-500/40 transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Top line: Name & Date */}
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                        {record.input.fullName}
                      </h4>
                      <p className="text-xs text-slate-400">
                        {record.input.city} · {record.input.employmentType}
                      </p>
                    </div>

                    <span className="text-[10px] font-mono text-slate-400">
                      {new Date(record.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </span>
                  </div>

                  {/* 3 Metric Pills */}
                  <div className="mt-4 grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-900/80 border border-white/5 text-center">
                    <div>
                      <div className="text-[10px] font-mono text-slate-400">Eligibility</div>
                      <div className="text-sm font-bold text-cyan-400 font-mono mt-0.5">
                        {record.eligibilityPercentage}%
                      </div>
                    </div>

                    <div>
                      <div className="text-[10px] font-mono text-slate-400">Credit</div>
                      <div className="text-sm font-bold text-blue-400 font-mono mt-0.5">
                        {record.creditAnalysis.score}
                      </div>
                    </div>

                    <div>
                      <div className="text-[10px] font-mono text-slate-400">Risk</div>
                      <div className={`text-sm font-bold font-mono mt-0.5 ${riskColor}`}>
                        {record.riskLevel}
                      </div>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="mt-4 space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">Requested Loan:</span>
                      <span className="font-mono font-medium text-white">₹{record.input.desiredLoanAmount.toLocaleString('en-IN')}</span>
                    </div>

                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">Estimated Monthly EMI:</span>
                      <span className="font-mono font-bold text-white">₹{record.monthlyEmiEstimated.toLocaleString('en-IN')}</span>
                    </div>

                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">Monthly Income:</span>
                      <span className="font-mono text-slate-300">₹{record.input.monthlyIncome.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-[11px] text-slate-400">
                    <Database className="w-3 h-3 text-emerald-400" />
                    <span>Sheets: {record.sheetSynced ? 'Synced' : 'Saved'}</span>
                  </div>

                  <button
                    onClick={() => onSelectRecord(record)}
                    className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
                  >
                    <span>View Snapshot</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
