import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { LoanEligibilityForm } from './components/LoanEligibilityForm.tsx';
import { FinancialDashboard } from './components/FinancialDashboard.tsx';
import { EmiCalculator } from './components/EmiCalculator.tsx';
import { CreditAnalyzer } from './components/CreditAnalyzer.tsx';
import { HistoryView } from './components/HistoryView.tsx';
import { AiChatDrawer } from './components/AiChatDrawer.tsx';
import { Footer } from './components/Footer.tsx';
import { FinancialInput, FinSightAnalysisResult } from './types/finance.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'checker' | 'credit' | 'emi' | 'dashboard' | 'history'>('home');
  const [currentAnalysis, setCurrentAnalysis] = useState<FinSightAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  
  // Chat Drawer
  const [isChatDrawerOpen, setIsChatDrawerOpen] = useState(false);

  // Preload initial assessment into memory so the dashboard always has rich demo data if visited directly
  useEffect(() => {
    // If no analysis is loaded, fetch the latest from history
    fetch('/api/history')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.data) && data.data.length > 0) {
          setCurrentAnalysis(data.data[0]);
        }
      })
      .catch((err) => console.warn('History init sync notice:', err));
  }, []);

  const handleFormSubmit = async (data: FinancialInput, saveToSheets: boolean) => {
    setIsLoading(true);
    setErrorBanner(null);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          saveToSheets,
        }),
      });

      const responseData = await res.json();

      if (responseData.success && responseData.data) {
        setCurrentAnalysis(responseData.data);
        setActiveTab('dashboard');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setErrorBanner(responseData.error || 'Unable to complete AI analysis. Please verify your inputs.');
      }
    } catch (err: any) {
      console.error('Submission error:', err);
      setErrorBanner('Network error connecting to the FinSight AI server. Please verify your connection.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveToSheets = async (record: FinSightAnalysisResult): Promise<{ success: boolean; message: string }> => {
    try {
      const res = await fetch('/api/save-record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
      });
      const data = await res.json();
      return {
        success: data.success,
        message: data.message || 'Record successfully processed.',
      };
    } catch (err: any) {
      return {
        success: false,
        message: 'Saved in local activity session.',
      };
    }
  };

  const handleApplyEmiToChecker = (amount: number, tenure: number) => {
    setActiveTab('checker');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCheckLoanWithScore = (score: number, utilization: number) => {
    setActiveTab('checker');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 mesh-gradient-bg flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab: string) => {
          setActiveTab(tab as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Global Error Banner */}
        {errorBanner && (
          <div className="mb-6 p-4 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-rose-200 text-xs sm:text-sm flex items-center justify-between">
            <span>{errorBanner}</span>
            <button
              onClick={() => setErrorBanner(null)}
              className="px-2 py-1 text-xs text-rose-300 hover:text-white rounded"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Tab 1: Home / Landing View */}
        {activeTab === 'home' && (
          <div className="space-y-16">
            <Hero
              onCheckEligibility={() => {
                setActiveTab('checker');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onExploreTools={(toolId) => {
                if (toolId === 'tools-section') {
                  const el = document.getElementById('tools-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                } else {
                  setActiveTab(toolId as any);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
            />

            {/* Quick Ingestion Form Directly Accessible Below Hero */}
            <div className="pt-8 border-t border-white/10">
              <div className="text-center mb-10">
                <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
                  Instant Assessment
                </span>
                <h2 className="text-3xl font-bold text-white tracking-tight mt-2">
                  Check Your AI Loan Eligibility
                </h2>
                <p className="text-sm text-slate-400 max-w-xl mx-auto mt-1">
                  Complete the BFSI underwriting profile below to receive instant eligibility scoring, risk ratings, and Claude AI financial tips.
                </p>
              </div>

              <LoanEligibilityForm
                onSubmit={handleFormSubmit}
                isLoading={isLoading}
              />
            </div>
          </div>
        )}

        {/* Tab 2: Standalone Loan Eligibility Checker View */}
        {activeTab === 'checker' && (
          <div className="space-y-8 pt-4">
            <div className="text-center max-w-2xl mx-auto">
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
                Module 1 · Underwriting Engine
              </span>
              <h1 className="text-3xl font-extrabold text-white tracking-tight mt-2">
                AI Loan Eligibility Checker
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Evaluate your debt servicing capacity, benchmark borrowing limits, and examine multi-tenure repayment scenarios powered by Claude AI.
              </p>
            </div>

            <LoanEligibilityForm
              onSubmit={handleFormSubmit}
              isLoading={isLoading}
            />
          </div>
        )}

        {/* Tab 3: Standalone Credit Analyzer View */}
        {activeTab === 'credit' && (
          <div className="pt-4">
            <CreditAnalyzer
              onCheckLoanWithScore={handleCheckLoanWithScore}
            />
          </div>
        )}

        {/* Tab 4: Standalone EMI Calculator View */}
        {activeTab === 'emi' && (
          <div className="pt-4">
            <EmiCalculator
              onApplyToChecker={handleApplyEmiToChecker}
            />
          </div>
        )}

        {/* Tab 5: Dashboard / Results View */}
        {activeTab === 'dashboard' && (
          <div className="pt-4">
            {currentAnalysis ? (
              <FinancialDashboard
                analysis={currentAnalysis}
                onEditInputs={() => {
                  setActiveTab('checker');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onOpenChat={() => setIsChatDrawerOpen(true)}
                onSaveToSheets={handleSaveToSheets}
              />
            ) : (
              <div className="glass-panel p-12 text-center rounded-3xl border border-white/10 max-w-lg mx-auto">
                <h3 className="text-lg font-bold text-white">No Active Assessment</h3>
                <p className="text-xs text-slate-400 mt-2">
                  Complete the Loan Eligibility form to generate your AI Financial Snapshot and underwriting report.
                </p>
                <button
                  onClick={() => setActiveTab('checker')}
                  className="mt-6 px-6 py-2.5 rounded-xl bg-cyan-500 text-black font-semibold text-xs transition-colors"
                >
                  Start Loan Eligibility Assessment
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 6: Activity History View */}
        {activeTab === 'history' && (
          <div className="pt-4">
            <HistoryView
              onSelectRecord={(record) => {
                setCurrentAnalysis(record);
                setActiveTab('dashboard');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onStartNew={() => {
                setActiveTab('checker');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

      </main>

      {/* Footer */}
      <Footer
        onNavigate={(tab) => {
          setActiveTab(tab as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Floating Ask AI Button (Fixed bottom right) */}
      <div className="fixed bottom-6 right-6 z-30 print:hidden">
        <button
          onClick={() => setIsChatDrawerOpen(true)}
          className="px-4 py-3 rounded-full bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white font-semibold text-xs shadow-2xl shadow-violet-950/80 hover:shadow-cyan-500/30 transition-all flex items-center gap-2 border border-white/20 group hover:scale-105 active:scale-95"
        >
          <div className="w-2 h-2 rounded-full bg-cyan-300 animate-ping" />
          <span>Ask FinSight AI</span>
        </button>
      </div>

      {/* Interactive AI Chat Drawer */}
      <AiChatDrawer
        isOpen={isChatDrawerOpen}
        onClose={() => setIsChatDrawerOpen(false)}
        currentAnalysis={currentAnalysis}
      />

    </div>
  );
}
